<template>
  <header class="header">
    <div class="container">
      <div class="header-content">
        <div class="logo">
          <h1>KUA Penjaringan</h1>
          <p class="tagline">Kantor Urusan Agama Kecamatan Penjaringan</p>
        </div>

        <button class="mobile-menu-btn" @click="toggleMenu" :class="{ active: isMenuOpen }">
          <span></span>
          <span></span>
          <span></span>
        </button>

        <nav class="nav" :class="{ open: isMenuOpen }">
          <router-link to="/" @click="closeMenu">Beranda</router-link>
          <router-link to="/layanan" @click="closeMenu">Layanan</router-link>
          <router-link to="/artikel" @click="closeMenu">Artikel</router-link>
          <router-link to="/kegiatan" @click="closeMenu">Kegiatan</router-link>
          <router-link to="/kontak" @click="closeMenu">Kontak</router-link>
        </nav>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: 'AppHeader',
  data() {
    return {
      isMenuOpen: false
    };
  },
  methods: {
    toggleMenu() {
      this.isMenuOpen = !this.isMenuOpen;
    },
    closeMenu() {
      this.isMenuOpen = false;
    }
  }
};
</script>

<style scoped>
.header {
  background: linear-gradient(135deg, #17272b 0%, #2bbede 100%);
  color: white;
  padding: 1rem 0;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  position: sticky;
  top: 0;
  z-index: 1000;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1.5rem;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo h1 {
  margin: 0;
  font-size: 1.8rem;
  font-weight: 700;
}

.tagline {
  margin: 0;
  font-size: 0.85rem;
  opacity: 0.9;
}

.nav {
  display: flex;
  gap: 2rem;
}

.nav a {
  color: white;
  text-decoration: none;
  font-weight: 500;
  transition: opacity 0.3s;
  padding: 0.5rem 0;
}

.nav a:hover {
  opacity: 0.8;
}

.nav a.router-link-active {
  border-bottom: 2px solid white;
}

.mobile-menu-btn {
  display: none;
  flex-direction: column;
  gap: 5px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 5px;
}

.mobile-menu-btn span {
  width: 25px;
  height: 3px;
  background: white;
  transition: all 0.3s;
}

.mobile-menu-btn.active span:nth-child(1) {
  transform: rotate(45deg) translate(8px, 8px);
}

.mobile-menu-btn.active span:nth-child(2) {
  opacity: 0;
}

.mobile-menu-btn.active span:nth-child(3) {
  transform: rotate(-45deg) translate(7px, -7px);
}

@media (max-width: 768px) {
  .mobile-menu-btn {
    display: flex;
  }

  .nav {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: #17272b;
    flex-direction: column;
    padding: 1rem;
    gap: 0;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
  }

  .nav.open {
    max-height: 400px;
  }

  .nav a {
    padding: 1rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  }

  .logo h1 {
    font-size: 1.3rem;
  }

  .tagline {
    font-size: 0.7rem;
  }
}
</style>

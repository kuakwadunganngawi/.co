<template>
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <h3>KUA Penjaringan</h3>
          <p>Kantor Urusan Agama Kecamatan Penjaringan, Jakarta Utara</p>
          <p>Melayani dengan sepenuh hati untuk kemaslahatan umat</p>
        </div>

        <div class="footer-section">
          <h4>Layanan</h4>
          <ul>
            <li><a href="#" @click.prevent>Administrasi Nikah</a></li>
            <li><a href="#" @click.prevent>Konseling Pranikah</a></li>
            <li><a href="#" @click.prevent>Bimbingan Keluarga</a></li>
            <li><a href="#" @click.prevent>Kursus Calon Pengantin</a></li>
          </ul>
        </div>

        <div class="footer-section">
          <h4>Kontak</h4>
          <ul>
            <li>Jl. Raya Penjaringan</li>
            <li>Jakarta Utara, DKI Jakarta</li>
            <li>Telp: (021) 1234-5678</li>
            <li>Email: info@kuapenjaringan.site</li>
          </ul>
        </div>

        <div class="footer-section">
          <h4>Jam Operasional</h4>
          <ul>
            <li>Senin - Kamis: 08.00 - 16.00</li>
            <li>Jumat: 08.00 - 16.30</li>
            <li>Sabtu: 08.00 - 13.00</li>
            <li>Minggu & Libur: Tutup</li>
          </ul>
        </div>
      </div>

      <div class="footer-bottom">
        <p>&copy; 2024 KUA Penjaringan. All rights reserved.</p>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'AppFooter'
};
</script>

<style scoped>
.footer {
  background: #17272b;
  color: white;
  padding: 3rem 0 1rem;
  margin-top: 4rem;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1.5rem;
}

.footer-content {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-bottom: 2rem;
}

.footer-section h3 {
  color: #2bbede;
  margin-bottom: 1rem;
  font-size: 1.5rem;
}

.footer-section h4 {
  color: #2bbede;
  margin-bottom: 1rem;
  font-size: 1.1rem;
}

.footer-section p {
  line-height: 1.6;
  opacity: 0.9;
}

.footer-section ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.footer-section ul li {
  margin-bottom: 0.5rem;
  opacity: 0.9;
}

.footer-section ul li a {
  color: white;
  text-decoration: none;
  transition: color 0.3s;
}

.footer-section ul li a:hover {
  color: #2bbede;
}

.footer-bottom {
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding-top: 1.5rem;
  text-align: center;
  opacity: 0.8;
}

@media (max-width: 768px) {
  .footer-content {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }
}
</style>

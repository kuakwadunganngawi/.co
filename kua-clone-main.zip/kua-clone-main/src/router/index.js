import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/Home.vue';
import Services from '../views/Services.vue';
import Articles from '../views/Articles.vue';
import Activities from '../views/Activities.vue';
import Contact from '../views/Contact.vue';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/layanan',
    name: 'Services',
    component: Services
  },
  {
    path: '/artikel',
    name: 'Articles',
    component: Articles
  },
  {
    path: '/kegiatan',
    name: 'Activities',
    component: Activities
  },
  {
    path: '/kontak',
    name: 'Contact',
    component: Contact
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior() {
    return { top: 0 };
  }
});

export default router;

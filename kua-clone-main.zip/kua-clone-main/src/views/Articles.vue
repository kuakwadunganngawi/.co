<template>
  <div class="articles-page">
    <section class="page-header">
      <div class="container">
        <h1>Artikel Terbaru</h1>
        <p>Informasi dan edukasi seputar keagamaan dan kehidupan berkeluarga</p>
      </div>
    </section>

    <section class="articles-section">
      <div class="container">
        <div class="articles-grid">
          <div v-for="article in articles" :key="article.id" class="article-card">
            <div class="article-image" :style="{ backgroundImage: `url(${article.image})` }"></div>
            <div class="article-content">
              <div class="article-meta">
                <span class="date">{{ formatDate(article.date) }}</span>
                <span class="author">{{ article.author }}</span>
              </div>
              <h2>{{ article.title }}</h2>
              <p>{{ article.excerpt }}</p>
              <div class="article-full" v-if="article.expanded">
                <p>{{ article.content }}</p>
              </div>
              <button @click="toggleArticle(article)" class="read-more-btn">
                {{ article.expanded ? 'Tutup' : 'Baca Selengkapnya' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'Articles',
  data() {
    return {
      articles: [
        {
          id: 1,
          title: 'Pentingnya Kursus Pranikah untuk Membangun Keluarga Sakinah',
          excerpt: 'Mempersiapkan diri menuju pernikahan dengan pemahaman yang matang tentang kehidupan berumah tangga.',
          content: 'Kursus pranikah merupakan salah satu persiapan penting sebelum memasuki jenjang pernikahan. Dalam kursus ini, calon pengantin akan mendapatkan pemahaman mendalam tentang hak dan kewajiban suami istri, komunikasi dalam rumah tangga, manajemen keuangan keluarga, dan berbagai aspek penting lainnya yang akan membantu membangun keluarga yang harmonis dan bahagia. Program ini juga mencakup materi kesehatan reproduksi, parenting, dan penyelesaian konflik rumah tangga secara islami.',
          image: 'https://images.pexels.com/photos/265722/pexels-photo-265722.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA',
          expanded: false
        },
        {
          id: 2,
          title: 'Moderasi Beragama: Kunci Kerukunan Umat',
          excerpt: 'Membangun pemahaman tentang pentingnya sikap moderat dalam beragama.',
          content: 'Moderasi beragama adalah cara pandang dan sikap yang seimbang dalam memahami dan mengamalkan ajaran agama. KUA Penjaringan aktif mengkampanyekan moderasi beragama sebagai upaya menjaga keharmonisan dan toleransi antarumat beragama di wilayah Jakarta Utara. Moderasi beragama mengajarkan kita untuk tidak ekstrem, baik dalam pemikiran maupun tindakan, serta menghormati perbedaan keyakinan sebagai sunnatullah.',
          image: 'https://images.pexels.com/photos/1416530/pexels-photo-1416530.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA',
          expanded: false
        },
        {
          id: 3,
          title: 'Prosedur Pendaftaran Nikah Online di KUA Penjaringan',
          excerpt: 'Panduan lengkap pendaftaran nikah secara online yang mudah dan praktis.',
          content: 'Kemudahan akses layanan adalah prioritas kami. Kini pendaftaran nikah dapat dilakukan secara online melalui sistem SIMKAH. Calon pengantin cukup mengakses website resmi, mengisi formulir, dan mengunggah dokumen yang diperlukan. Tim kami akan memverifikasi dan menghubungi untuk jadwal konseling pranikah. Proses online ini menghemat waktu dan memberikan fleksibilitas bagi calon pengantin yang sibuk.',
          image: 'https://images.pexels.com/photos/6962021/pexels-photo-6962021.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA',
          expanded: false
        },
        {
          id: 4,
          title: 'Zakat Fitrah dan Zakat Mal: Memahami Perbedaannya',
          excerpt: 'Penjelasan lengkap tentang jenis-jenis zakat dan kewajiban menunaikannya.',
          content: 'Zakat fitrah adalah zakat yang wajib dikeluarkan setiap muslim menjelang Idul Fitri, sedangkan zakat mal adalah zakat yang dikeluarkan dari harta yang telah mencapai nisab dan haul. KUA Penjaringan melayani penerimaan zakat dari masyarakat dan menyalurkannya kepada yang berhak menerimanya (mustahik) secara transparan dan akuntabel. Mari tunaikan kewajiban zakat untuk mensucikan harta dan membantu sesama.',
          image: 'https://images.pexels.com/photos/8553895/pexels-photo-8553895.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA',
          expanded: false
        },
        {
          id: 5,
          title: 'Wakaf Produktif untuk Kesejahteraan Umat',
          excerpt: 'Bagaimana wakaf dapat memberikan manfaat berkelanjutan untuk masyarakat.',
          content: 'Wakaf produktif adalah wakaf yang dikelola secara profesional untuk menghasilkan manfaat ekonomi berkelanjutan. KUA Penjaringan mendampingi dan memfasilitasi masyarakat yang ingin berwakaf, baik wakaf tanah, bangunan, maupun wakaf uang. Hasil pengelolaan wakaf produktif dapat digunakan untuk membangun fasilitas pendidikan, kesehatan, dan pemberdayaan ekonomi umat. Mari berwakaf untuk investasi akhirat yang tidak akan pernah putus pahalanya.',
          image: 'https://images.pexels.com/photos/6646917/pexels-photo-6646917.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA',
          expanded: false
        },
        {
          id: 6,
          title: 'Tips Membangun Komunikasi Efektif dalam Rumah Tangga',
          excerpt: 'Kunci keharmonisan keluarga dimulai dari komunikasi yang baik.',
          content: 'Komunikasi adalah fondasi utama dalam membangun rumah tangga yang harmonis. Pasangan suami istri perlu belajar mendengarkan dengan empati, menyampaikan pendapat dengan baik, dan menyelesaikan perbedaan secara dewasa. KUA Penjaringan menyediakan layanan konseling keluarga untuk membantu pasangan meningkatkan kualitas komunikasi dalam rumah tangga. Ingat, masalah sekecil apapun akan menjadi besar jika tidak dikomunikasikan dengan baik.',
          image: 'https://images.pexels.com/photos/3184398/pexels-photo-3184398.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 17 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA',
          expanded: false
        }
      ]
    };
  },
  methods: {
    formatDate(date) {
      return new Intl.DateTimeFormat('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }).format(date);
    },
    toggleArticle(article) {
      article.expanded = !article.expanded;
    }
  }
};
</script>

<style scoped>
.page-header {
  background: linear-gradient(135deg, #2bbede 0%, #17272b 100%);
  color: white;
  padding: 3rem 0;
  text-align: center;
}

.page-header h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

.page-header p {
  font-size: 1.1rem;
  opacity: 0.95;
}

.articles-section {
  padding: 4rem 0;
}

.articles-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
}

.article-card {
  background: white;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.article-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 15px rgba(43, 190, 222, 0.2);
}

.article-image {
  height: 250px;
  background-size: cover;
  background-position: center;
}

.article-content {
  padding: 2rem;
}

.article-meta {
  display: flex;
  justify-content: space-between;
  color: #999;
  font-size: 0.85rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.article-card h2 {
  color: #17272b;
  margin-bottom: 1rem;
  font-size: 1.4rem;
  line-height: 1.4;
}

.article-card p {
  color: #666;
  line-height: 1.6;
  margin-bottom: 1rem;
}

.article-full {
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid #eee;
}

.read-more-btn {
  background: #2bbede;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 5px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s;
}

.read-more-btn:hover {
  background: #239db8;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(43, 190, 222, 0.3);
}

@media (max-width: 768px) {
  .page-header h1 {
    font-size: 1.8rem;
  }

  .articles-grid {
    grid-template-columns: 1fr;
  }

  .article-image {
    height: 200px;
  }
}
</style>

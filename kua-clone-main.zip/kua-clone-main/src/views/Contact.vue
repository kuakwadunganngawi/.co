<template>
  <div class="contact-page">
    <section class="page-header">
      <div class="container">
        <h1>Hubungi Kami</h1>
        <p>Kami siap melayani Anda dengan sepenuh hati</p>
      </div>
    </section>

    <section class="contact-section">
      <div class="container">
        <div class="contact-grid">
          <div class="contact-info">
            <h2>Informasi Kontak</h2>
            <p class="intro">Untuk informasi lebih lanjut atau pertanyaan, silakan hubungi kami melalui:</p>

            <div class="info-item">
              <div class="info-icon">📍</div>
              <div>
                <h3>Alamat</h3>
                <p>Jl. Raya Penjaringan<br>Jakarta Utara, DKI Jakarta 14450</p>
              </div>
            </div>

            <div class="info-item">
              <div class="info-icon">📞</div>
              <div>
                <h3>Telepon</h3>
                <p>(021) 1234-5678<br>(021) 8765-4321</p>
              </div>
            </div>

            <div class="info-item">
              <div class="info-icon">📧</div>
              <div>
                <h3>Email</h3>
                <p>info@kuapenjaringan.site<br>admin@kuapenjaringan.site</p>
              </div>
            </div>

            <div class="info-item">
              <div class="info-icon">🕐</div>
              <div>
                <h3>Jam Operasional</h3>
                <p>
                  Senin - Kamis: 08.00 - 16.00 WIB<br>
                  Jumat: 08.00 - 16.30 WIB<br>
                  Sabtu: 08.00 - 13.00 WIB<br>
                  Minggu & Libur Nasional: Tutup
                </p>
              </div>
            </div>
          </div>

          <div class="contact-form-wrapper">
            <h2>Kirim Pesan</h2>
            <form @submit.prevent="handleSubmit" class="contact-form">
              <div class="form-group">
                <label for="name">Nama Lengkap *</label>
                <input
                  type="text"
                  id="name"
                  v-model="form.name"
                  required
                  placeholder="Masukkan nama lengkap Anda"
                />
              </div>

              <div class="form-group">
                <label for="email">Email *</label>
                <input
                  type="email"
                  id="email"
                  v-model="form.email"
                  required
                  placeholder="nama@email.com"
                />
              </div>

              <div class="form-group">
                <label for="phone">Nomor Telepon</label>
                <input
                  type="tel"
                  id="phone"
                  v-model="form.phone"
                  placeholder="08xxxxxxxxxx"
                />
              </div>

              <div class="form-group">
                <label for="subject">Subjek *</label>
                <select id="subject" v-model="form.subject" required>
                  <option value="">Pilih subjek</option>
                  <option value="nikah">Pendaftaran Nikah</option>
                  <option value="konseling">Konseling Pranikah</option>
                  <option value="kursus">Kursus Calon Pengantin</option>
                  <option value="zakat">Zakat & Wakaf</option>
                  <option value="lainnya">Lainnya</option>
                </select>
              </div>

              <div class="form-group">
                <label for="message">Pesan *</label>
                <textarea
                  id="message"
                  v-model="form.message"
                  required
                  rows="5"
                  placeholder="Tuliskan pesan atau pertanyaan Anda"
                ></textarea>
              </div>

              <button type="submit" class="submit-btn">Kirim Pesan</button>

              <div v-if="submitMessage" class="submit-message" :class="submitStatus">
                {{ submitMessage }}
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <section class="map-section">
      <div class="container">
        <h2>Lokasi Kami</h2>
        <div class="map-placeholder">
          <p>Peta Lokasi KUA Penjaringan</p>
          <p class="map-note">Jl. Raya Penjaringan, Jakarta Utara</p>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'Contact',
  data() {
    return {
      form: {
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      },
      submitMessage: '',
      submitStatus: ''
    };
  },
  methods: {
    handleSubmit() {
      this.submitMessage = 'Terima kasih! Pesan Anda telah terkirim. Kami akan segera menghubungi Anda.';
      this.submitStatus = 'success';

      this.form = {
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      };

      setTimeout(() => {
        this.submitMessage = '';
        this.submitStatus = '';
      }, 5000);
    }
  }
};
</script>

<style scoped>
.page-header {
  background: linear-gradient(135deg, #2bbede 0%, #17272b 100%);
  color: white;
  padding: 3rem 0;
  text-align: center;
}

.page-header h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

.page-header p {
  font-size: 1.1rem;
  opacity: 0.95;
}

.contact-section {
  padding: 4rem 0;
}

.contact-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
}

.contact-info h2,
.contact-form-wrapper h2 {
  color: #17272b;
  margin-bottom: 1.5rem;
  font-size: 1.8rem;
}

.intro {
  color: #666;
  line-height: 1.6;
  margin-bottom: 2rem;
}

.info-item {
  display: flex;
  gap: 1.5rem;
  margin-bottom: 2rem;
  padding-bottom: 2rem;
  border-bottom: 1px solid #eee;
}

.info-item:last-child {
  border-bottom: none;
}

.info-icon {
  font-size: 2rem;
  flex-shrink: 0;
}

.info-item h3 {
  color: #2bbede;
  margin-bottom: 0.5rem;
  font-size: 1.2rem;
}

.info-item p {
  color: #666;
  line-height: 1.8;
  margin: 0;
}

.contact-form-wrapper {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: block;
  color: #17272b;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 0.875rem;
  border: 2px solid #e0e0e0;
  border-radius: 5px;
  font-size: 1rem;
  transition: border-color 0.3s;
  font-family: inherit;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #2bbede;
}

.form-group textarea {
  resize: vertical;
}

.submit-btn {
  width: 100%;
  padding: 1rem;
  background: #2bbede;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
}

.submit-btn:hover {
  background: #239db8;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(43, 190, 222, 0.4);
}

.submit-message {
  margin-top: 1rem;
  padding: 1rem;
  border-radius: 5px;
  text-align: center;
  font-weight: 500;
}

.submit-message.success {
  background: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.map-section {
  background: #f8f9fa;
  padding: 4rem 0;
}

.map-section h2 {
  text-align: center;
  color: #17272b;
  font-size: 2rem;
  margin-bottom: 2rem;
}

.map-placeholder {
  background: linear-gradient(135deg, #2bbede, #17272b);
  height: 400px;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.map-placeholder p {
  font-size: 1.5rem;
  margin: 0.5rem 0;
}

.map-note {
  font-size: 1rem;
  opacity: 0.9;
}

@media (max-width: 768px) {
  .page-header h1 {
    font-size: 1.8rem;
  }

  .contact-grid {
    grid-template-columns: 1fr;
    gap: 2rem;
  }

  .map-placeholder {
    height: 300px;
  }

  .map-placeholder p {
    font-size: 1.2rem;
  }
}
</style>

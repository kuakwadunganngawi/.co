<template>
  <div class="services-page">
    <section class="page-header">
      <div class="container">
        <h1>Layanan Keagamaan</h1>
        <p>Berbagai layanan terpadu untuk melayani kebutuhan keagamaan masyarakat Penjaringan</p>
      </div>
    </section>

    <section class="services-section">
      <div class="container">
        <div class="services-grid">
          <div v-for="service in services" :key="service.id" class="service-card">
            <div class="service-icon">{{ service.icon }}</div>
            <h3>{{ service.title }}</h3>
            <p>{{ service.description }}</p>
            <div class="service-details">
              <h4>Persyaratan:</h4>
              <ul>
                <li v-for="(req, index) in service.requirements" :key="index">{{ req }}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="registration-info">
      <div class="container">
        <h2>Cara Pendaftaran Online</h2>
        <div class="steps">
          <div class="step">
            <div class="step-number">1</div>
            <h3>Persiapan Dokumen</h3>
            <p>Siapkan dokumen yang diperlukan sesuai layanan yang akan digunakan</p>
          </div>
          <div class="step">
            <div class="step-number">2</div>
            <h3>Registrasi Online</h3>
            <p>Isi formulir pendaftaran online melalui sistem SIMKAH</p>
          </div>
          <div class="step">
            <div class="step-number">3</div>
            <h3>Verifikasi</h3>
            <p>Tim kami akan memverifikasi dan menghubungi Anda</p>
          </div>
          <div class="step">
            <div class="step-number">4</div>
            <h3>Pelayanan</h3>
            <p>Datang ke KUA sesuai jadwal yang telah ditentukan</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'Services',
  data() {
    return {
      services: [
        {
          id: 1,
          icon: '📝',
          title: 'Administrasi Nikah',
          description: 'Layanan pendaftaran dan pencatatan pernikahan sesuai syariat Islam dan hukum negara. Proses cepat dan mudah dengan pelayanan profesional.',
          requirements: [
            'KTP Calon Pengantin',
            'Kartu Keluarga',
            'Surat Keterangan dari Kelurahan',
            'Pas Foto 2x3 (4 lembar)',
            'Surat Izin Orang Tua (jika belum 21 tahun)'
          ]
        },
        {
          id: 2,
          icon: '💑',
          title: 'Konseling Pranikah',
          description: 'Bimbingan dan konseling untuk calon pengantin sebelum menikah. Membantu mempersiapkan kehidupan rumah tangga yang harmonis.',
          requirements: [
            'Surat Panggilan dari KUA',
            'KTP Calon Pengantin',
            'Bukti Pendaftaran Nikah',
            'Mengikuti minimal 3 sesi konseling'
          ]
        },
        {
          id: 3,
          icon: '👨‍👩‍👧‍👦',
          title: 'Bimbingan Keluarga',
          description: 'Konseling dan bimbingan untuk keharmonisan keluarga sakinah. Mengatasi permasalahan rumah tangga dengan pendekatan islami.',
          requirements: [
            'KTP Suami & Istri',
            'Buku Nikah',
            'Membuat janji konsultasi terlebih dahulu',
            'Kesediaan mengikuti program bimbingan'
          ]
        },
        {
          id: 4,
          icon: '🎓',
          title: 'Kursus Calon Pengantin',
          description: 'Program pelatihan dan edukasi untuk calon pengantin mencakup materi keagamaan, kesehatan reproduksi, dan manajemen keluarga.',
          requirements: [
            'Telah mendaftar nikah di KUA',
            'KTP Calon Pengantin',
            'Mengisi formulir pendaftaran kursus',
            'Membayar biaya administrasi'
          ]
        },
        {
          id: 5,
          icon: '✅',
          title: 'Sertifikasi Halal',
          description: 'Layanan konsultasi dan pendampingan sertifikasi halal untuk pelaku usaha makanan dan minuman.',
          requirements: [
            'NIB (Nomor Induk Berusaha)',
            'Daftar produk yang akan disertifikasi',
            'Dokumen standar operasional produksi',
            'Surat permohonan sertifikasi'
          ]
        },
        {
          id: 6,
          icon: '🤲',
          title: 'Zakat & Wakaf',
          description: 'Pengelolaan dan penyaluran zakat, infaq, dan wakaf untuk kesejahteraan umat. Transparansi dan akuntabilitas terjamin.',
          requirements: [
            'KTP Muzakki/Wakif',
            'Mengisi formulir penyerahan',
            'Bukti kepemilikan harta (untuk wakaf)',
            'Menyerahkan langsung atau transfer'
          ]
        }
      ]
    };
  }
};
</script>

<style scoped>
.page-header {
  background: linear-gradient(135deg, #2bbede 0%, #17272b 100%);
  color: white;
  padding: 3rem 0;
  text-align: center;
}

.page-header h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

.page-header p {
  font-size: 1.1rem;
  opacity: 0.95;
}

.services-section {
  padding: 4rem 0;
}

.services-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
}

.service-card {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.service-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 15px rgba(43, 190, 222, 0.2);
}

.service-icon {
  font-size: 3.5rem;
  margin-bottom: 1rem;
}

.service-card h3 {
  color: #2bbede;
  margin-bottom: 1rem;
  font-size: 1.4rem;
}

.service-card > p {
  color: #666;
  line-height: 1.6;
  margin-bottom: 1.5rem;
}

.service-details h4 {
  color: #17272b;
  margin-bottom: 0.75rem;
  font-size: 1.1rem;
}

.service-details ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.service-details ul li {
  color: #666;
  padding: 0.5rem 0;
  padding-left: 1.5rem;
  position: relative;
}

.service-details ul li::before {
  content: '✓';
  color: #2bbede;
  font-weight: bold;
  position: absolute;
  left: 0;
}

.registration-info {
  background: #f8f9fa;
  padding: 4rem 0;
}

.registration-info h2 {
  text-align: center;
  color: #17272b;
  font-size: 2rem;
  margin-bottom: 3rem;
}

.steps {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
}

.step {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  text-align: center;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.step-number {
  width: 60px;
  height: 60px;
  background: linear-gradient(135deg, #2bbede, #17272b);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  font-weight: bold;
  margin: 0 auto 1.5rem;
}

.step h3 {
  color: #2bbede;
  margin-bottom: 1rem;
  font-size: 1.3rem;
}

.step p {
  color: #666;
  line-height: 1.6;
}

@media (max-width: 768px) {
  .page-header h1 {
    font-size: 1.8rem;
  }

  .services-grid {
    grid-template-columns: 1fr;
  }

  .steps {
    grid-template-columns: 1fr;
  }
}
</style>

<template>
  <div class="activities-page">
    <section class="page-header">
      <div class="container">
        <h1>Kegiatan Terbaru</h1>
        <p>Berbagai kegiatan dan program KUA Penjaringan untuk umat</p>
      </div>
    </section>

    <section class="activities-section">
      <div class="container">
        <div class="activities-grid">
          <div v-for="activity in activities" :key="activity.id" class="activity-card">
            <div class="activity-image" :style="{ backgroundImage: `url(${activity.image})` }">
              <div class="activity-status" :class="activity.status">
                {{ activity.status === 'upcoming' ? 'Akan Datang' : 'Selesai' }}
              </div>
            </div>
            <div class="activity-content">
              <div class="activity-meta">
                <span class="date">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M11 0H5v2h6V0zm-1 3H6v2h4V3zM4 6h8v8H4V6zm1 1v6h6V7H5z"/>
                  </svg>
                  {{ formatDate(activity.date) }}
                </span>
                <span class="location">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M8 0a5 5 0 0 0-5 5c0 2.5 5 11 5 11s5-8.5 5-11a5 5 0 0 0-5-5zm0 8a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
                  </svg>
                  {{ activity.location }}
                </span>
              </div>
              <h2>{{ activity.title }}</h2>
              <p>{{ activity.description }}</p>
              <div class="activity-details" v-if="activity.details">
                <h4>Detail Kegiatan:</h4>
                <ul>
                  <li v-for="(detail, index) in activity.details" :key="index">{{ detail }}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="upcoming-events">
      <div class="container">
        <h2>Agenda Mendatang</h2>
        <div class="timeline">
          <div v-for="event in upcomingEvents" :key="event.id" class="timeline-item">
            <div class="timeline-date">{{ formatShortDate(event.date) }}</div>
            <div class="timeline-content">
              <h3>{{ event.title }}</h3>
              <p>{{ event.time }} - {{ event.location }}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'Activities',
  data() {
    return {
      activities: [
        {
          id: 1,
          title: 'Pelatihan Manasik Haji 2025',
          description: 'KUA Penjaringan mengadakan pelatihan manasik haji untuk mempersiapkan jamaah yang akan menunaikan ibadah haji tahun 2025. Pelatihan meliputi tata cara ibadah, doa-doa, dan tips kesehatan selama di tanah suci.',
          image: 'https://images.pexels.com/photos/5212780/pexels-photo-5212780.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
          location: 'Aula KUA Penjaringan',
          status: 'upcoming',
          details: [
            'Tata cara ibadah haji dari awal hingga akhir',
            'Praktik manasik secara langsung',
            'Tips kesehatan di tanah suci',
            'Pengurusan dokumen dan perlengkapan',
            'Gratis untuk semua jamaah haji'
          ]
        },
        {
          id: 2,
          title: 'Bazar Ramadan & Santunan Anak Yatim',
          description: 'Menyambut bulan suci Ramadan, KUA Penjaringan menggelar bazar dan kegiatan sosial berupa santunan kepada anak yatim dan dhuafa di wilayah Penjaringan.',
          image: 'https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          location: 'Halaman KUA Penjaringan',
          status: 'upcoming',
          details: [
            'Bazar makanan dan pakaian',
            'Santunan untuk 200 anak yatim',
            'Pembagian paket sembako',
            'Pengajian dan kultum',
            'Terbuka untuk umum'
          ]
        },
        {
          id: 3,
          title: 'Seminar Keluarga Sakinah',
          description: 'Seminar dengan tema "Membangun Keluarga Berkualitas di Era Digital" menghadirkan narasumber ahli psikologi keluarga dan tokoh agama untuk memberikan pencerahan kepada pasangan suami istri.',
          image: 'https://images.pexels.com/photos/3184398/pexels-photo-3184398.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
          location: 'Aula Kecamatan Penjaringan',
          status: 'completed',
          details: [
            'Materi komunikasi dalam keluarga',
            'Parenting di era digital',
            'Mengelola keuangan rumah tangga',
            'Dihadiri 150 pasangan',
            'Mendapat sambutan positif dari peserta'
          ]
        },
        {
          id: 4,
          title: 'Khataman Al-Quran Bersama',
          description: 'Kegiatan khataman Al-Quran rutin yang diselenggarakan setiap bulan sebagai sarana silaturahmi dan peningkatan keimanan masyarakat.',
          image: 'https://images.pexels.com/photos/6933267/pexels-photo-6933267.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          location: 'Masjid Al-Ikhlas Penjaringan',
          status: 'completed',
          details: [
            'Pembacaan Al-Quran juz 1-30',
            'Doa bersama',
            'Tausiyah dari Ustadz',
            'Konsumsi dan snack',
            'Dihadiri jamaah dari berbagai RT/RW'
          ]
        },
        {
          id: 5,
          title: 'Pelatihan Pengelolaan Masjid',
          description: 'Workshop untuk pengurus masjid se-Kecamatan Penjaringan tentang manajemen masjid modern, pengelolaan keuangan, dan program pemberdayaan jamaah.',
          image: 'https://images.pexels.com/photos/2291004/pexels-photo-2291004.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
          location: 'Aula KUA Penjaringan',
          status: 'completed',
          details: [
            'Manajemen organisasi masjid',
            'Pengelolaan keuangan transparan',
            'Program pemberdayaan jamaah',
            'Pemanfaatan teknologi',
            'Diikuti 45 pengurus masjid'
          ]
        },
        {
          id: 6,
          title: 'Donor Darah Kemanusiaan',
          description: 'Kegiatan donor darah bekerjasama dengan PMI DKI Jakarta sebagai wujud kepedulian sosial dan kemanusiaan.',
          image: 'https://images.pexels.com/photos/6823567/pexels-photo-6823567.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
          location: 'Halaman KUA Penjaringan',
          status: 'completed',
          details: [
            'Terkumpul 120 kantong darah',
            'Pemeriksaan kesehatan gratis',
            'Sertifikat dan snack untuk pendonor',
            'Bekerjasama dengan PMI Jakarta Utara',
            'Akan diadakan rutin setiap 3 bulan'
          ]
        }
      ],
      upcomingEvents: [
        {
          id: 1,
          title: 'Pengajian Rutin Ibu-Ibu',
          date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
          time: '09.00 - 11.00 WIB',
          location: 'Aula KUA'
        },
        {
          id: 2,
          title: 'Kursus Calon Pengantin Batch 5',
          date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          time: '08.00 - 15.00 WIB',
          location: 'Aula KUA'
        },
        {
          id: 3,
          title: 'Konseling Keluarga (by appointment)',
          date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
          time: '13.00 - 16.00 WIB',
          location: 'Ruang Konseling KUA'
        },
        {
          id: 4,
          title: 'Pelatihan Manasik Haji',
          date: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
          time: '08.00 - 16.00 WIB',
          location: 'Aula KUA'
        }
      ]
    };
  },
  methods: {
    formatDate(date) {
      return new Intl.DateTimeFormat('id-ID', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }).format(date);
    },
    formatShortDate(date) {
      return new Intl.DateTimeFormat('id-ID', {
        day: '2-digit',
        month: 'short'
      }).format(date);
    }
  }
};
</script>

<style scoped>
.page-header {
  background: linear-gradient(135deg, #2bbede 0%, #17272b 100%);
  color: white;
  padding: 3rem 0;
  text-align: center;
}

.page-header h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

.page-header p {
  font-size: 1.1rem;
  opacity: 0.95;
}

.activities-section {
  padding: 4rem 0;
}

.activities-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
}

.activity-card {
  background: white;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.activity-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 15px rgba(43, 190, 222, 0.2);
}

.activity-image {
  height: 250px;
  background-size: cover;
  background-position: center;
  position: relative;
}

.activity-status {
  position: absolute;
  top: 1rem;
  right: 1rem;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 600;
}

.activity-status.upcoming {
  background: #2bbede;
  color: white;
}

.activity-status.completed {
  background: #17272b;
  color: white;
}

.activity-content {
  padding: 2rem;
}

.activity-meta {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  color: #666;
  font-size: 0.9rem;
  margin-bottom: 1rem;
}

.activity-meta span {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.activity-card h2 {
  color: #17272b;
  margin-bottom: 1rem;
  font-size: 1.4rem;
  line-height: 1.4;
}

.activity-card > .activity-content > p {
  color: #666;
  line-height: 1.6;
  margin-bottom: 1.5rem;
}

.activity-details h4 {
  color: #2bbede;
  margin-bottom: 0.75rem;
  font-size: 1.1rem;
}

.activity-details ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.activity-details ul li {
  color: #666;
  padding: 0.4rem 0;
  padding-left: 1.5rem;
  position: relative;
  line-height: 1.5;
}

.activity-details ul li::before {
  content: '•';
  color: #2bbede;
  font-weight: bold;
  font-size: 1.2rem;
  position: absolute;
  left: 0;
}

.upcoming-events {
  background: #f8f9fa;
  padding: 4rem 0;
}

.upcoming-events h2 {
  text-align: center;
  color: #17272b;
  font-size: 2rem;
  margin-bottom: 3rem;
}

.timeline {
  max-width: 800px;
  margin: 0 auto;
  position: relative;
}

.timeline::before {
  content: '';
  position: absolute;
  left: 80px;
  top: 0;
  bottom: 0;
  width: 2px;
  background: #2bbede;
}

.timeline-item {
  display: flex;
  gap: 2rem;
  margin-bottom: 2rem;
  position: relative;
}

.timeline-date {
  width: 60px;
  height: 60px;
  background: linear-gradient(135deg, #2bbede, #17272b);
  color: white;
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 0.85rem;
  flex-shrink: 0;
  z-index: 1;
}

.timeline-content {
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  flex: 1;
}

.timeline-content h3 {
  color: #2bbede;
  margin-bottom: 0.5rem;
  font-size: 1.2rem;
}

.timeline-content p {
  color: #666;
  margin: 0;
}

@media (max-width: 768px) {
  .page-header h1 {
    font-size: 1.8rem;
  }

  .activities-grid {
    grid-template-columns: 1fr;
  }

  .activity-image {
    height: 200px;
  }

  .timeline::before {
    left: 30px;
  }

  .timeline-date {
    width: 50px;
    height: 50px;
    font-size: 0.75rem;
  }

  .timeline-item {
    gap: 1rem;
  }
}
</style>

<template>
  <div class="home">
    <section class="hero">
      <div class="container">
        <div class="hero-content">
          <h1>Selamat Datang di KUA Penjaringan</h1>
          <p>Kantor Urusan Agama Kecamatan Penjaringan, Jakarta Utara</p>
          <p class="hero-subtitle">Melayani dengan profesional untuk kemaslahatan umat Islam</p>
          <div class="hero-buttons">
            <router-link to="/layanan" class="btn btn-primary">Layanan Kami</router-link>
            <router-link to="/kontak" class="btn btn-secondary">Hubungi Kami</router-link>
          </div>
        </div>
      </div>
    </section>

    <section class="services-preview">
      <div class="container">
        <h2 class="section-title">Layanan Keagamaan</h2>
        <p class="section-subtitle">Berbagai layanan terpadu untuk melayani kebutuhan keagamaan masyarakat</p>

        <div class="services-grid">
          <div v-for="service in services" :key="service.id" class="service-card">
            <div class="service-icon">{{ service.icon }}</div>
            <h3>{{ service.title }}</h3>
            <p>{{ service.description }}</p>
          </div>
        </div>

        <div class="text-center">
          <router-link to="/layanan" class="btn btn-primary">Lihat Semua Layanan</router-link>
        </div>
      </div>
    </section>

    <section class="articles-preview">
      <div class="container">
        <h2 class="section-title">Artikel Terbaru</h2>
        <p class="section-subtitle">Informasi dan edukasi seputar keagamaan dan kehidupan berkeluarga</p>

        <div class="articles-grid">
          <div v-for="article in latestArticles" :key="article.id" class="article-card">
            <div class="article-image" :style="{ backgroundImage: `url(${article.image})` }"></div>
            <div class="article-content">
              <div class="article-meta">
                <span>{{ formatDate(article.date) }}</span>
                <span>{{ article.author }}</span>
              </div>
              <h3>{{ article.title }}</h3>
              <p>{{ article.excerpt }}</p>
            </div>
          </div>
        </div>

        <div class="text-center">
          <router-link to="/artikel" class="btn btn-primary">Baca Artikel Lainnya</router-link>
        </div>
      </div>
    </section>

    <section class="cta">
      <div class="container">
        <h2>Butuh Bantuan atau Informasi?</h2>
        <p>Tim kami siap membantu Anda dengan layanan terbaik</p>
        <router-link to="/kontak" class="btn btn-light">Hubungi Kami</router-link>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'Home',
  data() {
    return {
      services: [
        {
          id: 1,
          icon: '📝',
          title: 'Administrasi Nikah',
          description: 'Layanan pendaftaran dan pencatatan pernikahan sesuai syariat Islam dan hukum negara'
        },
        {
          id: 2,
          icon: '💑',
          title: 'Konseling Pranikah',
          description: 'Bimbingan dan konseling untuk calon pengantin sebelum menikah'
        },
        {
          id: 3,
          icon: '👨‍👩‍👧‍👦',
          title: 'Bimbingan Keluarga',
          description: 'Konseling dan bimbingan untuk keharmonisan keluarga sakinah'
        },
        {
          id: 4,
          icon: '🎓',
          title: 'Kursus Calon Pengantin',
          description: 'Program pelatihan dan edukasi untuk calon pengantin'
        },
        {
          id: 5,
          icon: '✅',
          title: 'Sertifikasi Halal',
          description: 'Layanan konsultasi dan pendampingan sertifikasi halal'
        },
        {
          id: 6,
          icon: '🤲',
          title: 'Zakat & Wakaf',
          description: 'Pengelolaan dan penyaluran zakat, infaq, dan wakaf'
        }
      ],
      latestArticles: [
        {
          id: 1,
          title: 'Pentingnya Kursus Pranikah untuk Membangun Keluarga Sakinah',
          excerpt: 'Mempersiapkan diri menuju pernikahan dengan pemahaman yang matang tentang kehidupan berumah tangga.',
          image: 'https://images.pexels.com/photos/265722/pexels-photo-265722.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA'
        },
        {
          id: 2,
          title: 'Moderasi Beragama: Kunci Kerukunan Umat',
          excerpt: 'Membangun pemahaman tentang pentingnya sikap moderat dalam beragama.',
          image: 'https://images.pexels.com/photos/1416530/pexels-photo-1416530.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA'
        },
        {
          id: 3,
          title: 'Prosedur Pendaftaran Nikah Online di KUA Penjaringan',
          excerpt: 'Panduan lengkap pendaftaran nikah secara online yang mudah dan praktis.',
          image: 'https://images.pexels.com/photos/6962021/pexels-photo-6962021.jpeg?auto=compress&cs=tinysrgb&w=800',
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          author: 'Admin KUA'
        }
      ]
    };
  },
  methods: {
    formatDate(date) {
      return new Intl.DateTimeFormat('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }).format(date);
    }
  }
};
</script>

<style scoped>
.hero {
  background: linear-gradient(135deg, #2bbede 0%, #17272b 100%);
  color: white;
  padding: 5rem 0;
  text-align: center;
}

.hero-content h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
  font-weight: 700;
}

.hero-content p {
  font-size: 1.2rem;
  margin-bottom: 0.5rem;
  opacity: 0.95;
}

.hero-subtitle {
  font-size: 1rem;
  opacity: 0.85;
  margin-bottom: 2rem;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
}

.section-title {
  text-align: center;
  font-size: 2rem;
  color: #17272b;
  margin-bottom: 0.5rem;
}

.section-subtitle {
  text-align: center;
  color: #666;
  margin-bottom: 3rem;
}

.services-preview,
.articles-preview {
  padding: 4rem 0;
}

.services-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
}

.service-card {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s, box-shadow 0.3s;
  text-align: center;
}

.service-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 15px rgba(43, 190, 222, 0.2);
}

.service-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
}

.service-card h3 {
  color: #2bbede;
  margin-bottom: 1rem;
  font-size: 1.3rem;
}

.service-card p {
  color: #666;
  line-height: 1.6;
}

.articles-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
}

.article-card {
  background: white;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.article-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 15px rgba(43, 190, 222, 0.2);
}

.article-image {
  height: 200px;
  background-size: cover;
  background-position: center;
}

.article-content {
  padding: 1.5rem;
}

.article-meta {
  display: flex;
  justify-content: space-between;
  color: #999;
  font-size: 0.85rem;
  margin-bottom: 1rem;
}

.article-card h3 {
  color: #17272b;
  margin-bottom: 0.75rem;
  font-size: 1.2rem;
  line-height: 1.4;
}

.article-card p {
  color: #666;
  line-height: 1.6;
}

.cta {
  background: linear-gradient(135deg, #2bbede 0%, #17272b 100%);
  color: white;
  padding: 4rem 0;
  text-align: center;
}

.cta h2 {
  font-size: 2rem;
  margin-bottom: 1rem;
}

.cta p {
  font-size: 1.1rem;
  margin-bottom: 2rem;
  opacity: 0.95;
}

.btn {
  display: inline-block;
  padding: 0.875rem 2rem;
  border-radius: 5px;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s;
}

.btn-primary {
  background: #2bbede;
  color: white;
}

.btn-primary:hover {
  background: #239db8;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(43, 190, 222, 0.4);
}

.btn-secondary {
  background: transparent;
  color: white;
  border: 2px solid white;
}

.btn-secondary:hover {
  background: white;
  color: #2bbede;
}

.btn-light {
  background: white;
  color: #2bbede;
}

.btn-light:hover {
  background: #f0f0f0;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(255, 255, 255, 0.3);
}

.text-center {
  text-align: center;
}

@media (max-width: 768px) {
  .hero-content h1 {
    font-size: 1.8rem;
  }

  .hero-content p {
    font-size: 1rem;
  }

  .section-title {
    font-size: 1.6rem;
  }

  .services-grid,
  .articles-grid {
    grid-template-columns: 1fr;
  }
}
</style>
